# 313239_Emb_C
## CI and Code Qaulity
|Build|CppCheck|Codacy|
|:--:|:--:|:--:|
[![Compile-Linux](https://github.com/sumedh-rao/313239_Emb_C/actions/workflows/complie.yml/badge.svg)](https://github.com/sumedh-rao/313239_Emb_C/actions/workflows/complie.yml)|[![Cppcheck](https://github.com/sumedh-rao/313239_Emb_C/actions/workflows/cpp.yml/badge.svg)](https://github.com/sumedh-rao/313239_Emb_C/actions/workflows/cpp.yml)|[![Codacy Badge](https://app.codacy.com/project/badge/Grade/a2aa446cd7e2406a856f90697ecaee5e)](https://www.codacy.com/gh/sumedh-rao/313239_Emb_C/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=sumedh-rao/313239_Emb_C&amp;utm_campaign=Badge_Grade)




-----------------
